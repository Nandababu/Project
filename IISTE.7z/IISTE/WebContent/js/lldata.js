/**
 * @param name
 * @returns
 */
function loadDetails(name) {
	var url = window.location.href;
	name = name.replace(/[\[\]]/g, "\\$&");
	var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"), results = regex
			.exec(url);
	if (!results)
		return null;
	if (!results[2])
		return '';
	return decodeURIComponent(results[2].replace(/\+/g), "");
}
/**
 * 
 */
function getLeaveData() {
	var id = loadDetails("userID");
	var key = loadDetails("Auth_Key");
	var session = loadDetails("Session");
	$
			.ajax({
				method : "GET",
				url : "getLeaveDataLL",
				data : {
					userid : id,
					authKey : key,
					session : session
				}
			})
			.done(
					function(msg) {
						var a = JSON.parse(msg)[0].length;
						var myTable = "<table id='leave_data'><tr><th>Employee ID</th><th>Employee Name</th><th>Leave Type</th><th>No. Of Days</th><th>Leave Reason</th><th>Leave Date</th><th>Rem. Casual Leave </th><th>Rem. Sick Leave </th><th>Your Comments</th><th colspan='3'>Action To Be Performed</th></tr>";
						for (var i = 0; i < a; i++) {
							myTable += "<tr><td>" + JSON.parse(msg)[0][i].id
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].name
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].type
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].days
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].reason
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].date
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].cl
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].sl
									+ "</td>";
							myTable += "<td><textarea rows='4' cols='5' maxlength='250' placeholder='Maximum 250 Characters' id='reason_leave"
									+ JSON.parse(msg)[0][i].id
									+ JSON.parse(msg)[0][i].date
									+ "' name='leave_reason'></textarea></td>";
							myTable += "<td onclick='leaveClick(this)'><img src='img/accept.png' title='Accept' alt='Accept' width='30' height='30'></td>";
							myTable += "<td onclick='leaveClick(this)'><img src='img/forward.jpg' title='Forward' alt='Forward' width='30' height='30'></td>";
							myTable += "<td onclick='leaveClick(this)'><img src='img/reject.png' title='Reject' alt='Reject' width='30' height='30'></td></tr>";
						}
						myTable += "</table>";
						document.getElementById('dialog').innerHTML = myTable;
						document.getElementById('leave_count').innerHTML = a;
					});

}
/**
 * 
 */
function getPermissionData() {
	var id = loadDetails("userID");
	var key = loadDetails("Auth_Key");
	var session = loadDetails("Session");
	$
			.ajax({
				method : "GET",
				url : "getPermissionDataLL",
				data : {
					userid : id,
					authKey : key,
					session : session
				}
			})
			.done(
					function(msg) {
						var b = JSON.parse(msg)[0].length;
						var myTable1 = "<table id='permission_data'><tr><th>Employee ID</th><th>Employee Name</th><th>Permission Hours</th><th>Permission Reason</th><th>Permission Date</th><th colspan='2'>Action To Be Performed</th></tr>";
						for (var i = 0; i < b; i++) {
							myTable1 += "<tr><td>" + JSON.parse(msg)[0][i].id
									+ "</td>";
							myTable1 += "<td>" + JSON.parse(msg)[0][i].name
									+ "</td>";
							myTable1 += "<td>" + JSON.parse(msg)[0][i].hour
									+ "</td>";
							myTable1 += "<td>" + JSON.parse(msg)[0][i].reason
									+ "</td>";
							myTable1 += "<td>" + JSON.parse(msg)[0][i].date
									+ "</td>";
							myTable1 += "<td onclick='permissionClick(this)'><img src='img/accept.png' title='Accept' alt='Accept' width='30' height='30'></td>";
							myTable1 += "<td onclick='permissionClick(this)'><img src='img/reject.png' title='Reject' alt='Reject' width='30' height='30'></td></tr>";
						}
						myTable1 += "</table>";
						document.getElementById('dialog1').innerHTML = myTable1;
						document.getElementById('permission_count').innerHTML = b;
					});

}
/**
 * 
 */
function getDetails() {
	var id = loadDetails("userID");
	var key = loadDetails("Auth_Key");
	var session = loadDetails("Session");
	$
			.ajax({
				method : "GET",
				url : "URLCheck",
				data : {
					userid : id,
					authKey : key,
					session : session
				}
			})
			.done(
					function(msg) {
						var result = JSON.parse(msg)[0];
						if (result.error === "invalidate") {
							window.location = "index.html";
						}
						document.getElementById("myImg").src = "http://192.168.0.226:3000/"
								+ result[0].id + ".jpg";
						$('#Employee_ID').html(result[0].id);
						$('#Employee_NAME').html(result[0].name);
						$('#project_NAME').html(result[0].projectname);
						$('#ll_NAME').html(result[0].llname);
						$('#pmo_NAME').html(result[0].pmoname);
						$('#casual_LEAVE').html(result[0].casualcount);
						$('#sick_LEAVE').html(result[0].sickcount);
						$('#per_HOUR').html(result[0].permission);
						var d = new Date();
						var n = d.getDate();
						var m = d.getMonth() + 1;
						var y = d.getFullYear();
						document.getElementById("datepicker").value = "0" + m
								+ "/" + "" + n + "/" + y;
						document.getElementById("datepicker_per").value = "0"
								+ m + "/" + "" + n + "/" + y;
					});
	count();
}
function count() {
	getLeaveData();
	getPermissionData();
}
/**
 * 
 */
function doLogout() {
	var session = loadDetails("Session");
	$.ajax({
		method : "POST",
		url : "URLCheck",
		data : {
			session : session
		}
	}).done(function(logout) {
		if (logout === "invalidate") {
			window.location = "index.html";
		}
	});
}
function leaveClick(rowNode) {
	var delRow = rowNode.parentNode.rowIndex;
	var selectedRow = document.getElementById('leave_data').rows;
	var empID = selectedRow[rowNode.parentNode.rowIndex].cells[0].innerHTML;
	var leaveType = selectedRow[rowNode.parentNode.rowIndex].cells[2].innerHTML;
	var leaveDays = selectedRow[rowNode.parentNode.rowIndex].cells[3].innerHTML;
	var leaveDate = selectedRow[rowNode.parentNode.rowIndex].cells[5].innerHTML;
	var status;
	if (rowNode.cellIndex == "9") {
		status = "1";
	} else if (rowNode.cellIndex == "10") {
		status = "2";
	} else if (rowNode.cellIndex == "11") {
		status = "3";
	}
	$.ajax({
		method : "GET",
		url : "updateLeaveStatus",
		data : {
			empID : empID,
			leaveDate : leaveDate,
			leaveType : leaveType,
			leaveDays : leaveDays,
			leaveReason : $('#reason_leave' + empID + leaveDate).val(),
			status : status
		}
	}).done(function(msg) {
		document.getElementById("leave_data").deleteRow(delRow);
		count();
	});

}
function permissionClick(rowNode) {
	var delRow = rowNode.parentNode.rowIndex;
	var selectedRow = document.getElementById('permission_data').rows;
	var empID = selectedRow[rowNode.parentNode.rowIndex].cells[0].innerHTML;
	var permissionhour = selectedRow[rowNode.parentNode.rowIndex].cells[2].innerHTML;
	var permissionDate = selectedRow[rowNode.parentNode.rowIndex].cells[4].innerHTML;
	var status;
	if (rowNode.cellIndex == "5") {
		status = "1";
	} else if (rowNode.cellIndex == "6") {
		status = "2";
	}
	$.ajax({
		method : "GET",
		url : "updatePermissionStatus",
		data : {
			empID : empID,
			permissionhour : permissionhour,
			permissionDate : permissionDate,
			status : status
		}
	}).done(function(msg) {
		document.getElementById("permission_data").deleteRow(delRow);
		count();
	});

}
function getReqLeaveData() {
	var id = loadDetails("userID");
	var key = loadDetails("Auth_Key");
	var session = loadDetails("Session");
	$
			.ajax({
				method : "GET",
				url : "getLeaveDataUser",
				data : {
					userid : id,
					authKey : key,
					session : session
				}
			})
			.done(
					function(msg) {
						var a = JSON.parse(msg)[0].length;
						var myTable = "<table id='leave_data_table'><tr><th>Leave Date</th><th>Leave Status</th><th>Comments</th></tr>";
						for (var i = 0; i < a; i++) {
							myTable += "<tr><td>" + JSON.parse(msg)[0][i].date
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].status
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].comments
									+ "</td></tr>";
						}
						myTable += "</table>";
						document.getElementById('dialog2').innerHTML = myTable;
					});
}
function getReqPermissionData() {
	var id = loadDetails("userID");
	var key = loadDetails("Auth_Key");
	var session = loadDetails("Session");
	$
			.ajax({
				method : "GET",
				url : "getPermissionDataUser",
				data : {
					userid : id,
					authKey : key,
					session : session
				}
			})
			.done(
					function(msg) {
						var a = JSON.parse(msg)[0].length;
						var myTable = "<table id='permission_data_table'><tr><th>Permission Date</th><th>Permission Status</th></tr>";
						for (var i = 0; i < a; i++) {
							myTable += "<tr><td>" + JSON.parse(msg)[0][i].date
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].status
									+ "</td></tr>";
						}
						myTable += "</table>";
						document.getElementById('dialog3').innerHTML = myTable;
					});
}
function getAcceptedLeaveData() {
	var id = loadDetails("userID");
	var key = loadDetails("Auth_Key");
	var session = loadDetails("Session");
	$
			.ajax({
				method : "GET",
				url : "getAcceptedLeaveRequestsLL",
				data : {
					userid : id,
					authKey : key,
					session : session
				}
			})
			.done(
					function(msg) {
						var a = JSON.parse(msg)[0].length;
						var myTable = "<table id='leave_req_data_table'><tr><th>Employee ID</th><th>Employee Name</th><th>Leave Type</th><th>No. Of Days</th><th>Leave Reason</th><th>Leave Date</th></tr>";
						for (var i = 0; i < a; i++) {
							myTable += "<tr><td>" + JSON.parse(msg)[0][i].id
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].name
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].type
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].days
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].reason
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].date
									+ "</td></tr>";
						}
						myTable += "</table>";
						document.getElementById('dialog4').innerHTML = myTable;
					});
}
function getRejectedLeaveData() {
	var id = loadDetails("userID");
	var key = loadDetails("Auth_Key");
	var session = loadDetails("Session");
	$
			.ajax({
				method : "GET",
				url : "getRejectedLeaveRequestsLL",
				data : {
					userid : id,
					authKey : key,
					session : session
				}
			})
			.done(
					function(msg) {
						var a = JSON.parse(msg)[0].length;
						var myTable = "<table id='leave_rej_data_table'><tr><th>Employee ID</th><th>Employee Name</th><th>Leave Type</th><th>No. Of Days</th><th>Leave Reason</th><th>Leave Date</th></tr>";
						for (var i = 0; i < a; i++) {
							myTable += "<tr><td>" + JSON.parse(msg)[0][i].id
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].name
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].type
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].days
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].reason
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].date
									+ "</td></tr>";
						}
						myTable += "</table>";
						document.getElementById('dialog5').innerHTML = myTable;
					});
}
function getForwardedLeaveData() {
	var id = loadDetails("userID");
	var key = loadDetails("Auth_Key");
	var session = loadDetails("Session");
	$
			.ajax({
				method : "GET",
				url : "getForwardedLeaveRequestsLL",
				data : {
					userid : id,
					authKey : key,
					session : session
				}
			})
			.done(
					function(msg) {
						var a = JSON.parse(msg)[0].length;
						var myTable = "<table id='leave_for_data_table'><tr><th>Employee ID</th><th>Employee Name</th><th>Leave Type</th><th>No. Of Days</th><th>Leave Reason</th><th>Leave Date</th><th>Leave Status</th></tr>";
						for (var i = 0; i < a; i++) {
							myTable += "<tr><td>" + JSON.parse(msg)[0][i].id
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].name
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].type
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].days
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].reason
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].date
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].status
									+ "</td></tr>";
						}
						myTable += "</table>";
						document.getElementById('dialog6').innerHTML = myTable;
					});
}
function getAcceptedPermissionData() {
	var id = loadDetails("userID");
	var key = loadDetails("Auth_Key");
	var session = loadDetails("Session");
	$
			.ajax({
				method : "GET",
				url : "getAcceptedPermissionRequestsLL",
				data : {
					userid : id,
					authKey : key,
					session : session
				}
			})
			.done(
					function(msg) {
						var a = JSON.parse(msg)[0].length;
						var myTable = "<table id='per_acpt_data_table'><tr><th>Employee ID</th><th>Employee Name</th><th>Permission Reason</th><th>Permission Date</th></tr>";
						for (var i = 0; i < a; i++) {
							myTable += "<tr><td>" + JSON.parse(msg)[0][i].id
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].name
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].reason
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].date
									+ "</td></tr>";
						}
						myTable += "</table>";
						document.getElementById('dialog7').innerHTML = myTable;
					});
}
function getRejectedPermissionData() {
	var id = loadDetails("userID");
	var key = loadDetails("Auth_Key");
	var session = loadDetails("Session");
	$
			.ajax({
				method : "GET",
				url : "getRejectedPermissionRequestsLL",
				data : {
					userid : id,
					authKey : key,
					session : session
				}
			})
			.done(
					function(msg) {
						var a = JSON.parse(msg)[0].length;
						var myTable = "<table id='per_rej_data_table'><tr><th>Employee ID</th><th>Employee Name</th><th>Permission Reason</th><th>Permission Date</th></tr>";
						for (var i = 0; i < a; i++) {
							myTable += "<tr><td>" + JSON.parse(msg)[0][i].id
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].name
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].reason
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].date
									+ "</td></tr>";
						}
						myTable += "</table>";
						document.getElementById('dialog8').innerHTML = myTable;
					});
}
/**
 * 
 */
function leave_submit() {
	$
			.ajax({
				method : "GET",
				url : "LeaveApply",
				data : {
					userid : loadDetails("userID"),
					authKey : loadDetails("Auth_Key"),
					mode : "leave",
					leaveType : document.getElementById("leave_type").value,
					NoDays : document.getElementById("no_of_days").value,
					leaveReason : $("#reason").val(),
					leaveDate : $("#datepicker").val()
				}
			})
			.done(
					function(message) {
						if (message === "success") {
							document.getElementById("confirm_leave").innerHTML = "* Leave Registered Successfully *";
						} else if (message === "lspr") {
							document.getElementById("confirm_leave").innerHTML = "* Leave Registered permission cancelled *";
						} else if (message === "leaveregistered") {
							document.getElementById("confirm_leave").innerHTML = "* Leave Already Registered on this date *";
						} else if (message === "Reappliedsuccess") {
							document.getElementById("confirm_leave").innerHTML = "* Leave Reapplied on this date *";
						} else if (message === "Sick Leave") {
							document.getElementById("confirm_leave").innerHTML = "* Sick Leave Exceeds the Liimit *";
						} else if (message === "Casual Leave") {
							document.getElementById("confirm_leave").innerHTML = "* Casual Leave Exceeds the Liimit *";
						}
					});
}

/**
 * 
 */
function permission_submit() {
	$
			.ajax(
					{
						method : "GET",
						url : "LeaveApply",
						data : {
							userid : loadDetails("userID"),
							authKey : loadDetails("Auth_Key"),
							mode : "permission",
							permissionHours : document
									.getElementById("no_of_hours").value,
							permissionReason : $("#reason_per").val(),
							permissionDate : $("#datepicker_per").val()
						}
					})
			.done(
					function(message) {
						if (message === "success") {
							document.getElementById("confirm_permission").innerHTML = "* Permission Registered Successfully *";
						} else if (message === "pslr") {
							document.getElementById("confirm_permission").innerHTML = "* Permission Registered Leave cancelled *";
						} else if (message === "permissionregistered") {
							document.getElementById("confirm_permission").innerHTML = "* Permission Already Registered on this date *";
						} else if (message === "Reappliedsuccess") {
							document.getElementById("confirm_permission").innerHTML = "* Permission Reapplied on this date *";
						} else if (message === "permission") {
							document.getElementById("confirm_permission").innerHTML = "* Permission exceeds the limit *";
						}
					});
}
/**
 * 
 */
function resetParaLeave() {
	document.getElementById("confirm_leave").innerHTML = "";
}
/**
 * 
 */
function resetParaPermission() {
	document.getElementById("confirm_permission").innerHTML = "";
}