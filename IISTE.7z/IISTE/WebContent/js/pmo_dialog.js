$(function() {
	$("#dialog").dialog({
		autoOpen : false,
		height : 500,
		width : 1500,
		modal : true,
		show : {
			effect : "explode",
			duration : 500
		},
		hide : {
			effect : "clip",
			duration : 500
		},
		buttons : {
			Close : function() {
				$("#dialog").dialog("close");
			}
		}
	});
	$("#opener").on("click", function() {
		$("#dialog").dialog("open");
	});
});
$(function() {
	$("#dialog1").dialog({
		autoOpen : false,
		height : 500,
		width : 1500,
		modal : true,
		show : {
			effect : "explode",
			duration : 500
		},
		hide : {
			effect : "clip",
			duration : 500
		},
		buttons : {
			Close : function() {
				$("#dialog1").dialog("close");
			}
		}
	});
	$("#opener1").on("click", function() {
		$("#dialog1").dialog("open");
	});
});
$(function() {
	$("#dialog4").dialog({
		autoOpen : false,
		height : 500,
		width : 1400,
		modal : true,
		show : {
			effect : "explode",
			duration : 500
		},
		hide : {
			effect : "clip",
			duration : 500
		},
		buttons : {
			Close : function() {
				$("#dialog4").dialog("close");
			}
		}
	});
	$("#opener4").on("click", function() {
		$("#dialog4").dialog("open");
	});
});
$(function() {
	$("#dialog5").dialog({
		autoOpen : false,
		height : 500,
		width : 1400,
		modal : true,
		show : {
			effect : "explode",
			duration : 500
		},
		hide : {
			effect : "clip",
			duration : 500
		},
		buttons : {
			Close : function() {
				$("#dialog5").dialog("close");
			}
		}
	});
	$("#opener5").on("click", function() {
		$("#dialog5").dialog("open");
	});
});
$(function() {
	$("#dialog7").dialog({
		autoOpen : false,
		height : 500,
		width : 1400,
		modal : true,
		show : {
			effect : "explode",
			duration : 500
		},
		hide : {
			effect : "clip",
			duration : 500
		},
		buttons : {
			Close : function() {
				$("#dialog7").dialog("close");
			}
		}
	});
	$("#opener7").on("click", function() {
		$("#dialog7").dialog("open");
	});
});
$(function() {
	$("#dialog8").dialog({
		autoOpen : false,
		height : 500,
		width : 1400,
		modal : true,
		show : {
			effect : "explode",
			duration : 500
		},
		hide : {
			effect : "clip",
			duration : 500
		},
		buttons : {
			Close : function() {
				$("#dialog8").dialog("close");
			}
		}
	});
	$("#opener8").on("click", function() {
		$("#dialog8").dialog("open");
	});
});