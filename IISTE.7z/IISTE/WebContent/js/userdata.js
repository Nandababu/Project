/**
 * @param name
 * @returns
 */
function loadDetails(name) {
	var url = window.location.href;
	name = name.replace(/[\[\]]/g, "\\$&");
	var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"), results = regex
			.exec(url);
	if (!results)
		return null;
	if (!results[2])
		return '';
	return decodeURIComponent(results[2].replace(/\+/g), "");
}
/**
 * 
 */
function getDetails() {
	var id = loadDetails("userID");
	var key = loadDetails("Auth_Key");
	var session = loadDetails("Session");
	$
			.ajax({
				method : "GET",
				url : "URLCheck",
				data : {
					userid : id,
					authKey : key,
					session : session
				}
			})
			.done(
					function(msg) {
						var result = JSON.parse(msg)[0];
						if (result.error === "invalidate") {
							window.location = "index.html";
						}
						document.getElementById("myImg").src = "http://192.168.0.226:3000/"
								+ result[0].id + ".jpg";
						$('#Employee_ID').html(result[0].id);
						$('#Employee_NAME').html(result[0].name);
						$('#project_NAME').html(result[0].projectname);
						$('#ll_NAME').html(result[0].llname);
						$('#pmo_NAME').html(result[0].pmoname);
						$('#casual_LEAVE').html(result[0].casualcount);
						$('#sick_LEAVE').html(result[0].sickcount);
						$('#per_HOUR').html(result[0].permission);
						var d = new Date();
						var n = d.getDate();
						var m = d.getMonth() + 1;
						var y = d.getFullYear();
						document.getElementById("datepicker").value = "0" + m
								+ "/" + "" + n + "/" + y;
						document.getElementById("datepicker_per").value = "0"
								+ m + "/" + "" + n + "/" + y;
					});
}
/**
 * 
 */
function doLogout() {
	var session = loadDetails("Session");
	$.ajax({
		method : "POST",
		url : "URLCheck",
		data : {
			session : session
		}
	}).done(function(logout) {
		if (logout === "invalidate") {
			window.location = "index.html";
		}
	});
}
/**
 * 
 */
function leave_submit() {
	$
			.ajax({
				method : "GET",
				url : "LeaveApply",
				data : {
					userid : loadDetails("userID"),
					authKey : loadDetails("Auth_Key"),
					mode : "leave",
					leaveType : document.getElementById("leave_type").value,
					NoDays : document.getElementById("no_of_days").value,
					leaveReason : $("#reason").val(),
					leaveDate : $("#datepicker").val()
				}
			})
			.done(
					function(message) {
						if (message === "success") {
							document.getElementById("confirm_leave").innerHTML = "* Leave Registered Successfully *";
						} else if (message === "lspr") {
							document.getElementById("confirm_leave").innerHTML = "* Leave Registered permission cancelled *";
						} else if (message === "leaveregistered") {
							document.getElementById("confirm_leave").innerHTML = "* Leave Already Registered on this date *";
						} else if (message === "Reappliedsuccess") {
							document.getElementById("confirm_leave").innerHTML = "* Leave Reapplied on this date *";
						} else if (message === "Sick Leave") {
							document.getElementById("confirm_leave").innerHTML = "* Sick Leave Exceeds the Limit *";
						} else if (message === "Casual Leave") {
							document.getElementById("confirm_leave").innerHTML = "* Casual Leave Exceeds the Limit *";
						}
					});
}

/**
 * 
 */
function permission_submit() {
	$
			.ajax(
					{
						method : "GET",
						url : "LeaveApply",
						data : {
							userid : loadDetails("userID"),
							authKey : loadDetails("Auth_Key"),
							mode : "permission",
							permissionHours : document
									.getElementById("no_of_hours").value,
							permissionReason : $("#reason_per").val(),
							permissionDate : $("#datepicker_per").val()
						}
					})
			.done(
					function(message) {
						if (message === "success") {
							document.getElementById("confirm_permission").innerHTML = "* Permission Registered Successfully *";
						} else if (message === "pslr") {
							document.getElementById("confirm_permission").innerHTML = "* Permission Registered Leave cancelled *";
						} else if (message === "permissionregistered") {
							document.getElementById("confirm_permission").innerHTML = "* Permission Already Registered on this date *";
						} else if (message === "Reappliedsuccess") {
							document.getElementById("confirm_permission").innerHTML = "* Permission Reapplied on this date *";
						} else if (message === "permission") {
							document.getElementById("confirm_permission").innerHTML = "* Permission exceeds the limit *";
						}
					});
}
function getReqLeaveData() {
	var id = loadDetails("userID");
	var key = loadDetails("Auth_Key");
	var session = loadDetails("Session");
	$
			.ajax({
				method : "GET",
				url : "getLeaveDataUser",
				data : {
					userid : id,
					authKey : key,
					session : session
				}
			})
			.done(
					function(msg) {
						var a = JSON.parse(msg)[0].length;
						var myTable = "<table id='leave_data'><tr><th>Leave Date</th><th>Leave Status</th><th>Comments</th></tr>";
						for (var i = 0; i < a; i++) {
							myTable += "<tr><td>" + JSON.parse(msg)[0][i].date
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].status
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].comments
									+ "</td></tr>";
						}
						myTable += "</table>";
						document.getElementById('dialog').innerHTML = myTable;
					});
}
function getReqPermissionData() {
	var id = loadDetails("userID");
	var key = loadDetails("Auth_Key");
	var session = loadDetails("Session");
	$
			.ajax({
				method : "GET",
				url : "getPermissionDataUser",
				data : {
					userid : id,
					authKey : key,
					session : session
				}
			})
			.done(
					function(msg) {
						var a = JSON.parse(msg)[0].length;
						var myTable = "<table id='permission_data'><tr><th>Permission Date</th><th>Permission Status</th></tr>";
						for (var i = 0; i < a; i++) {
							myTable += "<tr><td>" + JSON.parse(msg)[0][i].date
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].status
									+ "</td></tr>";
						}
						myTable += "</table>";
						document.getElementById('dialog1').innerHTML = myTable;
					});
}
/**
 * 
 */
function resetParaLeave() {
	document.getElementById("confirm_leave").innerHTML = "";
}
/**
 * 
 */
function resetParaPermission() {
	document.getElementById("confirm_permission").innerHTML = "";
}