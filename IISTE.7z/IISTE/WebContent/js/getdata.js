function setFocus() {
	document.getElementById("mailId").focus();
}
/**
 * getEmpId() used to set photo
 */
function getEmpId() {
	var macky = document.forms["registerForm"]["mail_id"].value;
	$.ajax({
		method : "GET",
		url : "EmpIdServlet",
		data : {
			mackyId : macky,
		}
	}).done(function(msg) {
		if (msg === "") {
			document.getElementById("mailId").focus();
			document.forms["registerForm"]["emp_id"].value = "";
			$('p').html(" * Enter a Valid Mail ID * ");
		} else {
			document.getElementById("emp_pswd").focus();
			document.forms["registerForm"]["emp_id"].value = msg;
			$('p').html("");
		}
	});
}
/**
 * getEmpName() used to set welcome notification
 */
function userValidate() {
	var macky = document.forms["login_form"]["mail_id"].value;
	var password = document.forms["login_form"]["emp_pswd"].value;
	$.ajax({
		method : "POST",
		url : "Login",
		data : {
			mackyId : macky,
			passwd : password
		}
	}).done(function(msg) {
		var result = JSON.parse(msg)[0];
		if (result.error === "perror") {
			$('p').html(" * Please enter valid password * ");
		} else if (result.error === "rerror") {
			$('p').html(" * Please Register to login * ");
		} else if (result.error === "merror") {
			$('p').html(" * Please Enter valid Macky ID * ");
		} else if (result.error === "nil") {
			if (result.desig === "te") {
				window.location = "userProfile.html?" + result.url;
			} else if (result.desig === "ll") {
				window.location = "llpage.html?" + result.url;
			} else {
				window.location = "pmopage.html?" + result.url;
			}
		}
	});
}

/**
 * 
 */
function getStatus() {
	var empID = document.forms["registerForm"]["emp_id"].value;
	var macky = document.forms["registerForm"]["mail_id"].value;
	$
			.ajax(
					{
						method : 'POST',
						url : "register",
						data : {
							empID : empID,
							macky : macky,
							emp_pswd : document.forms["registerForm"]["emp_pswd"].value,
							emp_pswd_retype : document.forms["registerForm"]["emp_pswd_retype"].value
						}
					}).done(function(result) {
				if (result === "true") {
					window.location = "index.html";
				} else if (result === "false") {
					$('p').html(" * Employee Already Registered * ");
				} else if (result === "error") {
					$('p').html(" * Please Fill The Details Properly * ");
				}
			});
}
/**
 * 
 */
function doPasswordCheck() {
	var password = document.forms["registerForm"]["emp_pswd"].value;
	var retype_password = document.forms["registerForm"]["emp_pswd_retype"].value;
	if (password === retype_password) {
		if (password != "" && password.length >= 8) {
			document.getElementById("regButton").disabled = false;
			$('p').html("");
		} else {
			$('p').html(" * Password Should Have Minimum 8 Characters * ");
			$('#regButton').prop('disabled', true);
			document.getElementById("regButton").disabled = true;
		}
	} else {
		$('p').html(" * Password Does Not Match * ");
		document.getElementById("regButton").disabled = true;
	}
}