$(function() {
	$("#dialog").dialog({
		autoOpen : false,
		height : 300,
		width : 400,
		modal : true,
		show : {
			effect : "explode",
			duration : 500
		},
		hide : {
			effect : "clip",
			duration : 500
		},
		buttons : {
			Close : function() {
				$("#dialog").dialog("close");
			}
		}
	});
	$("#opener").on("click", function() {
		$("#dialog").dialog("open");
	});
});
$(function() {
	$("#dialog1").dialog({
		autoOpen : false,
		height : 300,
		width : 400,
		modal : true,
		show : {
			effect : "explode",
			duration : 500
		},
		hide : {
			effect : "clip",
			duration : 500
		},
		buttons : {
			Close : function() {
				$("#dialog1").dialog("close");
			}
		}
	});
	$("#opener1").on("click", function() {
		$("#dialog1").dialog("open");
	});
});