/**
 * @param name
 * @returns
 */
function loadDetails(name) {
	var url = window.location.href;
	name = name.replace(/[\[\]]/g, "\\$&");
	var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"), results = regex
			.exec(url);
	if (!results)
		return null;
	if (!results[2])
		return '';
	return decodeURIComponent(results[2].replace(/\+/g), "");
}
function getDetails() {
	var id = loadDetails("userID");
	var key = loadDetails("Auth_Key");
	var session = loadDetails("Session");
	$
			.ajax({
				method : "GET",
				url : "URLCheck",
				data : {
					userid : id,
					authKey : key,
					session : session
				}
			})
			.done(
					function(msg) {
						var result = JSON.parse(msg)[0];
						if (result.error === "invalidate") {
							window.location = "index.html";
						}
						document.getElementById("myImg").src = "http://192.168.0.226:3000/"
								+ result[0].id + ".jpg";
						$('#Employee_ID').html(result[0].id);
						$('#Employee_NAME').html(result[0].name);
						$('#project_NAME').html(result[0].projectname);
						$('#ll_NAME').html(result[0].llname);
						$('#pmo_NAME').html(result[0].pmoname);
						$('#casual_LEAVE').html(result[0].casualcount);
						$('#sick_LEAVE').html(result[0].sickcount);
						$('#per_HOUR').html(result[0].permission);
					});
	count();
}
function getLeaveData() {
	var id = loadDetails("userID");
	var key = loadDetails("Auth_Key");
	var session = loadDetails("Session");
	$
			.ajax({
				method : "GET",
				url : "getLeaveDataPmo",
				data : {
					userid : id,
					authKey : key,
					session : session
				}
			})
			.done(
					function(msg) {
						var a = JSON.parse(msg)[0].length;
						var myTable = "<table id='leave_data'><tr><th>Employee Photo</th><th>Employee ID</th><th>Employee Name</th><th>Leave Type</th><th>No. Of Days</th><th>Leave Reason</th><th>Leave Date</th><th>Rem. Casual Leave </th><th>Rem. Sick Leave </th><th>LL Name</th><th>Your Comments</th><th colspan='2'>Action To Be Performed</th></tr>";
						for (var i = 0; i < a; i++) {
							myTable += "<tr><td>" + JSON.parse(msg)[0][i].id
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].id
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].name
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].type
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].days
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].reason
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].date
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].cl
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].sl
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].llname
									+ "</td>";
							myTable += "<td><textarea rows='4' cols='5' maxlength='250' placeholder='Maximum 250 Characters' id='reason_leave"
									+ JSON.parse(msg)[0][i].id
									+ JSON.parse(msg)[0][i].date
									+ "' name='leave_reason'></textarea></td>";
							myTable += "<td onclick='leaveClick(this)'><img src='img/accept.png' title='Accept' alt='Accept' width='30' height='30'></td>";
							myTable += "<td onclick='leaveClick(this)'><img src='img/reject.png' title='Reject' alt='Reject' width='30' height='30'></td></tr>";
						}
						myTable += "</table>";
						document.getElementById('dialog').innerHTML = myTable;
						document.getElementById('leave_count').innerHTML = a;
					});

}
function leaveClick(rowNode) {
	var delRow = rowNode.parentNode.rowIndex;
	var selectedRow = document.getElementById('leave_data').rows;
	var empID = selectedRow[rowNode.parentNode.rowIndex].cells[1].innerHTML;
	var leaveType = selectedRow[rowNode.parentNode.rowIndex].cells[3].innerHTML;
	var leaveDays = selectedRow[rowNode.parentNode.rowIndex].cells[4].innerHTML;
	var leaveDate = selectedRow[rowNode.parentNode.rowIndex].cells[6].innerHTML;
	var status;
	if (rowNode.cellIndex == "11") {
		status = "4";
	} else if (rowNode.cellIndex == "12") {
		status = "5";
	}
	$.ajax({
		method : "GET",
		url : "updateLeaveStatusPmo",
		data : {
			empID : empID,
			leaveDate : leaveDate,
			leaveType : leaveType,
			leaveDays : leaveDays,
			leaveReason : $('#reason_leave' + empID + leaveDate).val(),
			status : status
		}
	}).done(function(msg) {
		document.getElementById("leave_data").deleteRow(delRow);
		count();
	});

}
/**
 * 
 */
function getPermissionData() {
	var id = loadDetails("userID");
	var key = loadDetails("Auth_Key");
	var session = loadDetails("Session");
	$
			.ajax({
				method : "GET",
				url : "getPermissionDataPmo",
				data : {
					userid : id,
					authKey : key,
					session : session
				}
			})
			.done(
					function(msg) {
						var b = JSON.parse(msg)[0].length;
						var myTable1 = "<table id='permission_data'><tr><th>Employee Photo</th><th>Employee ID</th><th>Employee Name</th><th>Permission Hours</th><th>Permission Reason</th><th>Permission Date</th><th colspan='2'>Action To Be Performed</th></tr>";
						for (var i = 0; i < b; i++) {
							myTable1 += "<tr><td>" + JSON.parse(msg)[0][i].id
									+ "</td>";
							myTable1 += "<td>" + JSON.parse(msg)[0][i].id
									+ "</td>";
							myTable1 += "<td>" + JSON.parse(msg)[0][i].name
									+ "</td>";
							myTable1 += "<td>" + JSON.parse(msg)[0][i].hour
									+ "</td>";
							myTable1 += "<td>" + JSON.parse(msg)[0][i].reason
									+ "</td>";
							myTable1 += "<td>" + JSON.parse(msg)[0][i].date
									+ "</td>";
							myTable1 += "<td onclick='permissionClick(this)'><img src='img/accept.png' title='Accept' alt='Accept' width='30' height='30'></td>";
							myTable1 += "<td onclick='permissionClick(this)'><img src='img/reject.png' title='Reject' alt='Reject' width='30' height='30'></td></tr>";
						}
						myTable1 += "</table>";
						document.getElementById('dialog1').innerHTML = myTable1;
						document.getElementById('permission_count').innerHTML = b;
					});

}
function count() {
	getLeaveData();
	getPermissionData();
}
function permissionClick(rowNode) {
	var delRow = rowNode.parentNode.rowIndex;
	var selectedRow = document.getElementById('permission_data').rows;
	var empID = selectedRow[rowNode.parentNode.rowIndex].cells[1].innerHTML;
	var permissionhour = selectedRow[rowNode.parentNode.rowIndex].cells[3].innerHTML;
	var permissionDate = selectedRow[rowNode.parentNode.rowIndex].cells[5].innerHTML;
	var status;
	if (rowNode.cellIndex == "6") {
		status = "4";
	} else if (rowNode.cellIndex == "7") {
		status = "5";
	}
	$.ajax({
		method : "GET",
		url : "updatePermissionStatusPmo",
		data : {
			empID : empID,
			permissionhour : permissionhour,
			permissionDate : permissionDate,
			status : status
		}
	}).done(function(msg) {
		document.getElementById("permission_data").deleteRow(delRow);
		count();
	});

}
/**
 * 
 */
function doLogout() {
	var session = loadDetails("Session");
	$.ajax({
		method : "POST",
		url : "URLCheck",
		data : {
			session : session
		}
	}).done(function(logout) {
		if (logout === "invalidate") {
			window.location = "index.html";
		}
	});
}
function getAcceptedPermissionData() {
	var id = loadDetails("userID");
	var key = loadDetails("Auth_Key");
	var session = loadDetails("Session");
	$
			.ajax({
				method : "GET",
				url : "getAcceptedPermissionRequestsPmo",
				data : {
					userid : id,
					authKey : key,
					session : session
				}
			})
			.done(
					function(msg) {
						var a = JSON.parse(msg)[0].length;
						var myTable = "<table id='per_acpt_data_table'><tr><th>Employee ID</th><th>Employee Name</th><th>Permission Reason</th><th>Permission Date</th></tr>";
						for (var i = 0; i < a; i++) {
							myTable += "<tr><td>" + JSON.parse(msg)[0][i].id
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].name
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].reason
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].date
									+ "</td></tr>";
						}
						myTable += "</table>";
						document.getElementById('dialog7').innerHTML = myTable;
					});
}
function getRejectedPermissionData() {
	var id = loadDetails("userID");
	var key = loadDetails("Auth_Key");
	var session = loadDetails("Session");
	$
			.ajax({
				method : "GET",
				url : "getRejectedPermissionRequestsPmo",
				data : {
					userid : id,
					authKey : key,
					session : session
				}
			})
			.done(
					function(msg) {
						var a = JSON.parse(msg)[0].length;
						var myTable = "<table id='per_rej_data_table'><tr><th>Employee ID</th><th>Employee Name</th><th>Permission Reason</th><th>Permission Date</th></tr>";
						for (var i = 0; i < a; i++) {
							myTable += "<tr><td>" + JSON.parse(msg)[0][i].id
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].name
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].reason
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].date
									+ "</td></tr>";
						}
						myTable += "</table>";
						document.getElementById('dialog8').innerHTML = myTable;
					});
}
function getAcceptedLeaveData() {
	var id = loadDetails("userID");
	var key = loadDetails("Auth_Key");
	var session = loadDetails("Session");
	$
			.ajax({
				method : "GET",
				url : "getAcceptedLeaveRequestsPmo",
				data : {
					userid : id,
					authKey : key,
					session : session
				}
			})
			.done(
					function(msg) {
						var a = JSON.parse(msg)[0].length;
						var myTable = "<table id='leave_req_data_table'><tr><th>Employee ID</th><th>Employee Name</th><th>Leave Type</th><th>No. Of Days</th><th>Leave Reason</th><th>Leave Date</th><th>Leave Approved By</th></tr>";
						for (var i = 0; i < a; i++) {
							myTable += "<tr><td>" + JSON.parse(msg)[0][i].id
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].name
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].type
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].days
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].reason
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].date
									+ "</td>";
							myTable += "<td>"
									+ JSON.parse(msg)[0][i].acceptedby
									+ "</td></tr>";
						}
						myTable += "</table>";
						document.getElementById('dialog4').innerHTML = myTable;
					});
}
function getRejectedLeaveData() {
	var id = loadDetails("userID");
	var key = loadDetails("Auth_Key");
	var session = loadDetails("Session");
	$
			.ajax({
				method : "GET",
				url : "getRejectedLeaveRequestsPmo",
				data : {
					userid : id,
					authKey : key,
					session : session
				}
			})
			.done(
					function(msg) {
						var a = JSON.parse(msg)[0].length;
						var myTable = "<table id='leave_rej_data_table'><tr><th>Employee ID</th><th>Employee Name</th><th>Leave Type</th><th>No. Of Days</th><th>Leave Reason</th><th>Leave Date</th><th>Accepted By</th></tr>";
						for (var i = 0; i < a; i++) {
							myTable += "<tr><td>" + JSON.parse(msg)[0][i].id
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].name
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].type
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].days
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].reason
									+ "</td>";
							myTable += "<td>" + JSON.parse(msg)[0][i].date
									+ "</td>";
							myTable += "<td>"
									+ JSON.parse(msg)[0][i].acceptedby
									+ "</td></tr>";
						}
						myTable += "</table>";
						document.getElementById('dialog5').innerHTML = myTable;
					});
}