import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.arnx.jsonic.JSON;

/**
 * Servlet implementation class getLeaveDataUser
 */
public class getLeaveDataUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
	connections connection = new connections();
	Statement statement = null;
	ResultSet resultSetURL;
	userCheck chkusr = new userCheck();
	String empno;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public getLeaveDataUser() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		List<List<Map<String, String>>> resultList = new ArrayList<List<Map<String, String>>>();
		List<Map<String, String>> leaveList = new ArrayList<Map<String, String>>();
		Map<String, String> leaveMap = null;
		PrintWriter out = response.getWriter();
		try {
			statement = connection.connect().createStatement();
			String id = request.getParameter("userid");
			String query = "select employeeid from info_leave_master_data where employeeid='"
					+ id + "'";
			ResultSet rs = statement.executeQuery(query);
			while (rs.next()) {
				empno = rs.getString("employeeid");
			}
			String leaveDetails = "select requestedleavedate, leavestatus, llcomments, pmocomments from info_leave_update where employeeid='"
					+ empno + "' and  leavestatus is not null";
			ResultSet leaveResult = statement.executeQuery(leaveDetails);
			while (leaveResult.next()) {
				leaveMap = new HashMap<String, String>();
				String leaveDate = leaveResult.getString("requestedleavedate")
						.substring(0, 10);
				String comments = null;
				String displayData = null;
				if (leaveResult.getString("leavestatus").equals("0")) {
					displayData = "Leave Requested To TL";
					comments = "----------";
				} else if (leaveResult.getString("leavestatus").equals("1")) {
					displayData = "Leave Accepted By TL";
					comments = leaveResult.getString("llcomments");
				} else if (leaveResult.getString("leavestatus").equals("2")) {
					displayData = "Leave Forwarded By TL";
					comments = "----------";
				} else if (leaveResult.getString("leavestatus").equals("3")) {
					displayData = "Leave Rejected By TL";
					comments = leaveResult.getString("llcomments");
				} else if (leaveResult.getString("leavestatus").equals("4")) {
					displayData = "Leave Accepted By PMO";
					comments = leaveResult.getString("pmocomments");
				} else if (leaveResult.getString("leavestatus").equals("5")) {
					displayData = "Leave Rejected By PMO";
					comments = leaveResult.getString("pmocomments");
				} else if (leaveResult.getString("leavestatus").equals("6")) {
					displayData = "Leave Requested To PMO";
					comments = "----------";
				}
				if (comments == null) {
					comments = "No Comments";
				}
				leaveMap.put("status", displayData);
				leaveMap.put("date", leaveDate);
				leaveMap.put("comments", comments);
				leaveList.add(leaveMap);
			}
			resultList.add(leaveList);
			out.write(JSON.encode(resultList));
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			try {
				if (statement != null)
					statement.close();
			} catch (SQLException sqlException) {

			}
			try {
				if (connection.connect() != null)
					connection.connect().close();

			} catch (SQLException sqlException) {
				sqlException.printStackTrace();
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
