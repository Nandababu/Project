import java.io.IOException;
import java.io.PrintWriter;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;

/**
 * retrieve implementation class retrieve
 */
public class register extends HttpServlet {
  connections connection = new connections();
  Statement statement = null;
  String encrypted_password = null;
  ResultSet resultSet;

  protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    // password encrypt

    PrintWriter out = response.getWriter();
    if ((request.getParameter("emp_pswd").equals(request.getParameter("emp_pswd_retype")))
        && request.getParameter("emp_pswd_retype").length() >= 8) {
      try {
        encrypted_password = Leave_password_encrypt.encryption(request.getParameter("emp_pswd_retype"));
      } catch (NoSuchAlgorithmException NoSuchAlgorithmException) {
        NoSuchAlgorithmException.printStackTrace();
      } catch (NoSuchProviderException NoSuchProviderException) {
        NoSuchProviderException.printStackTrace();
      }
      try {
        statement = connection.connect().createStatement();
        String checkData = " select mackyid from INFO_LEAVE_MASTER_DATA WHERE employeeid like '"
            + request.getParameter("empID") + "'";
        resultSet = statement.executeQuery(checkData);
        while (resultSet.next()) {
          if (resultSet.getString("MACKYID").equals(request.getParameter("macky"))) {
            if (chk_usr(request.getParameter("empID")) == null) {
              String updateQuery = " UPDATE INFO_LEAVE_DATA SET employeeidentify = '" + encrypted_password
                  + "' WHERE employeeid like " + "'" + request.getParameter("empID") + "'";
              statement.executeUpdate(updateQuery);
              connection.connect().commit();
              out.write("true");
            } else {
              out.write("false");
            }
          }
        }
      } catch (SQLException e) {
        e.printStackTrace();
      } finally {
        try {
          if (statement != null)
            statement.close();
        } catch (SQLException sqlException) {

        }
        try {
          if (connection.connect() != null)
            connection.connect().close();
        } catch (SQLException sqlException) {
          sqlException.printStackTrace();
        }
      }
    } else {
      out.write("error");
    }
  }

  /**
   * Check_usr is used to check user already registered
   * 
   * @throws SQLException
   */
  public String chk_usr(String emp_id) throws SQLException {
    String employeeIdentify = null;
    String check_data = " SELECT employeeidentify FROM INFO_LEAVE_DATA WHERE employeeid like '" + emp_id + "'";
    resultSet = statement.executeQuery(check_data);
    while (resultSet.next()) {
      employeeIdentify = resultSet.getString("employeeidentify");
    }
    return employeeIdentify;
  }
}
