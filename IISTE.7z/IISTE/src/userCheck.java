import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Check the URL user and password
 */
public class userCheck {
	connections connection = new connections();
	Statement statement = null;
	ResultSet resultSetCheck, resultSetUpd, resultSetCountLeave,
			resultSetCountPermission;

	/**
	 * doCheckUser check user and authentication matches
	 * 
	 * @param id
	 * @param key
	 * @return
	 * @throws SQLException
	 */
	public String doCheckUser(String id, String key) throws SQLException {
		statement = connection.connect().createStatement();
		String checkQuery = "select count(*) as count from info_leave_data where EMPLOYEEID like '"
				+ id + "' and EMPLOYEEIDENTIFY like '" + key + "'";
		String count = null;
		resultSetCheck = statement.executeQuery(checkQuery);
		while (resultSetCheck.next()) {
			count = resultSetCheck.getString("count");
		}
		return count;
	}

	/**
	 * dateCheckValidate check date for requested date
	 * 
	 * @param Id
	 * @param date
	 * @return
	 * @throws SQLException
	 */
	public String dateCheckValidate(String id, String date, float noDays,
			float permissionTime) throws SQLException {
		statement = connection.connect().createStatement();
		String status = null, requestedLeaveDate = null, requestedPermissionDate = null, requestedLeavedays = null, leaveStatus = null, permissionStatus = null;
		int countLeaveDate = 0, countPermissionDate = 0;
		String CheckCountLeaveDate = " select count(*) as count from info_leave_update where employeeid='"
				+ id
				+ "' and requestedleavedate = to_date(' "
				+ date
				+ "','YYYY/MM/DD')";
		String CheckCountPermissionDate = " select count(*) as count from info_leave_update where employeeid='"
				+ id
				+ "' and requestedpermissiondate = to_date(' "
				+ date
				+ "','YYYY/MM/DD')";
		resultSetCountLeave = statement.executeQuery(CheckCountLeaveDate);
		while (resultSetCountLeave.next()) {
			countLeaveDate = Integer.parseInt(resultSetCountLeave
					.getString("count"));
		}
		resultSetCountPermission = statement
				.executeQuery(CheckCountPermissionDate);
		while (resultSetCountPermission.next()) {
			countPermissionDate = Integer.parseInt(resultSetCountPermission
					.getString("count"));
		}
		String checkDate = " SELECT requestedleavedate ,requestedpermissiondate,requesteddays,leavestatus,permissionstatus FROM INFO_LEAVE_UPDATE WHERE employeeid='"
				+ id
				+ "' and (requestedleavedate = to_date(' "
				+ date
				+ "','YYYY/MM/DD') or requestedpermissiondate = to_date('"
				+ date + "','YYYY/MM/DD'))";
		resultSetUpd = statement.executeQuery(checkDate);
		while (resultSetUpd.next()) {
			String LeaveDate, permissionDate;
			leaveStatus = resultSetUpd.getString("leavestatus");
			permissionStatus = resultSetUpd.getString("permissionstatus");
			LeaveDate = resultSetUpd.getString("requestedleavedate");
			if (LeaveDate != null) {
				requestedLeaveDate = LeaveDate.substring(0, 10);
			}
			permissionDate = resultSetUpd.getString("requestedpermissiondate");
			if (permissionDate != null) {
				requestedPermissionDate = permissionDate.substring(0, 10);
			}
			requestedLeavedays = resultSetUpd.getString("requesteddays");
		}
		if (!(noDays == 0)) {
			if (requestedLeaveDate == null && requestedPermissionDate == null) {
				status = "approveInsert";
			} else if (requestedLeaveDate == null
					&& requestedPermissionDate != null) {
				if (noDays == 0.5) {
					status = "approveLeaveUpdate";
				} else if (noDays >= 0.5) {
					status = "updateLeaveDeletePermission";
				}
			} else if (requestedLeaveDate != null) {
				if (leaveStatus.equals("3") || leaveStatus.equals("5")) {
					status = "approveLeaveUpdateStatus";
				} else {
					status = "leaveAlreadyRegistered";
				}
			}
		} else if (!(permissionTime == 0)) {
			if (requestedLeaveDate == null && requestedPermissionDate == null) {
				status = "approveInsert";
			} else if (requestedPermissionDate != null) {
				if (requestedPermissionDate.equals(requestedLeaveDate)) {
					if (permissionStatus.equals("3")
							|| permissionStatus.equals("5")) {
						status = "permissionApproveUpdateStatus";
					} else {
						status = "permissionAlreadyRegistered";
					}
				} else {
					status = "updatePermissionDeleteLeave";
				}
			} else if (requestedLeaveDate != null
					&& requestedPermissionDate == null) {
				if ((Float.parseFloat(requestedLeavedays) == 0.5 && permissionTime >= 0.5)) {
					status = "permissionApproveUpdate";
				} else if (Float.parseFloat(requestedLeavedays) > 0.5) {
					status = "updatePermissionDeleteLeave";
				}
			}
		}
		return status;
	}

	/**
	 * @param daysCount
	 * @param leaveType
	 * @throws SQLException
	 */
	public boolean leaveCountCheck(String leaveType, float countNumber,
			String empId) throws SQLException {
		statement = connection.connect().createStatement();
		Float LeaveCount = null;
		Boolean state = null;
		if (leaveType.equals("Casual Leave")) {
			String leaveDetails = "select casualleavecount from info_leave_data where employeeid like '"
					+ empId + "'";
			resultSetCheck = statement.executeQuery(leaveDetails);
			while (resultSetCheck.next()) {
				LeaveCount = Float.parseFloat(resultSetCheck
						.getString("casualleavecount"));
			}
			if (LeaveCount >= countNumber) {
				state = true;
			} else {
				state = false;
			}
		} else if (leaveType.equals("Sick Leave")) {
			String leaveDetails = "select sickleavecount from info_leave_data where employeeid like '"
					+ empId + "'";
			resultSetCheck = statement.executeQuery(leaveDetails);
			while (resultSetCheck.next()) {
				LeaveCount = Float.parseFloat(resultSetCheck
						.getString("sickleavecount"));
			}
			if (LeaveCount >= countNumber) {
				state = true;
			} else {
				state = false;
			}
		} else if (leaveType.equals("Permission")) {
			String leaveDetails = "select permissionhours from info_leave_data where employeeid like '"
					+ empId + "'";
			resultSetCheck = statement.executeQuery(leaveDetails);
			while (resultSetCheck.next()) {
				LeaveCount = Float.parseFloat(resultSetCheck
						.getString("permissionhours"));
			}
			if (LeaveCount >= countNumber) {
				state = true;
			} else {
				state = false;
			}
		}
		return state;
	}
}