import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class updatePermissionStatus
 */
public class updatePermissionStatus extends HttpServlet {
	private static final long serialVersionUID = 1L;
	connections connection = new connections();
	Statement statement = null;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public updatePermissionStatus() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		try {
			statement = connection.connect().createStatement();
			String empID = request.getParameter("empID");
			String permissionhour = request.getParameter("permissionhour");
			String permissionDate = request.getParameter("permissionDate");
			String status = request.getParameter("status");
			String result = null, hourCount = null;
			float count = 0;
			String casualleavecount = "select permissionhours from info_leave_data where employeeid='"
					+ empID + "'";
			ResultSet rs = statement.executeQuery(casualleavecount);
			while (rs.next()) {
				hourCount = rs.getString("permissionhours");
			}
			if (status.equals("1")) {
				String leaveCountUpdate = null;
				result = "1";
				count = Float.parseFloat(hourCount)
						- Float.parseFloat(permissionhour);
				leaveCountUpdate = "update info_leave_data set permissionhours="
						+ count + " where employeeid='" + empID + "'";
				int executeupdate = statement.executeUpdate(leaveCountUpdate);
				if (executeupdate > 0) {
					out.write("success");
				}
				connection.connect().commit();
			} else if (status.equals("2")) {
				result = "2";
			}
			SimpleDateFormat source = new SimpleDateFormat("yyyy-MM-dd");
			SimpleDateFormat target = new SimpleDateFormat("yyyy/MM/dd");
			String newDate = target.format(source.parse(permissionDate));
			String leaveupdate = "update info_leave_update set permissionstatus='"
					+ result
					+ "' where employeeid='"
					+ empID
					+ "' and requestedpermissiondate=TO_DATE('"
					+ newDate
					+ "','yyyy/MM/dd')";
			int execute = statement.executeUpdate(leaveupdate);
			if (execute > 0) {
				out.write("success");
			}
			connection.connect().commit();
		} catch (SQLException e) {

			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		} finally {
			try {
				if (statement != null)
					statement.close();
			} catch (SQLException sqlException) {

			}
			try {
				if (connection.connect() != null)
					connection.connect().close();

			} catch (SQLException sqlException) {
				sqlException.printStackTrace();
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
