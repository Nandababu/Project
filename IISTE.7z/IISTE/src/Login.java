import java.io.IOException;
import java.io.PrintWriter;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.arnx.jsonic.JSON;

/**
 * Servlet implementation class Login
 */
public class Login extends HttpServlet {
	connections connection = new connections();
	Statement statement = null;
	String encrypted_password = null;
	ResultSet resultSet;

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		List<Map<String, String>> dataList = new ArrayList<Map<String, String>>();
		Map<String, String> dataMap = null;
		try {
			encrypted_password = Leave_password_encrypt.encryption(request
					.getParameter("passwd"));
		} catch (NoSuchAlgorithmException NoSuchAlgorithmException) {
			NoSuchAlgorithmException.printStackTrace();
		} catch (NoSuchProviderException NoSuchProviderException) {
			NoSuchProviderException.printStackTrace();
		}
		try {
			statement = connection.connect().createStatement();
			String checkUser = " select EMPLOYEEID from INFO_LEAVE_MASTER_DATA WHERE mackyid like '"
					+ request.getParameter("mackyId") + "'";
			resultSet = statement.executeQuery(checkUser);
			if (resultSet.next()) {
				String checkLogin = "select e1.employeeid,e1.pmocheck,e1.employeeidentify,e2.lableadername "
						+ "from info_leave_data e1,info_leave_master_data e2 where e1.employeeid='"
						+ resultSet.getString("employeeid")
						+ "' and e2.employeeid='"
						+ resultSet.getString("employeeid") + "'";
				ResultSet resultSetLogin = statement.executeQuery(checkLogin);
				while (resultSetLogin.next()) {
					HttpSession session = request.getSession();
					if (resultSetLogin.getString("EMPLOYEEIDENTIFY") != null) {
						if (resultSetLogin.getString("EMPLOYEEIDENTIFY")
								.equals(encrypted_password)) {
							String url = "userID="
									+ resultSetLogin.getString("EMPLOYEEID")
									+ "&Auth_Key="
									+ resultSetLogin
											.getString("EMPLOYEEIDENTIFY")
									+ "&Session=" + session.getId() + "";
							if (resultSetLogin.getString("pmocheck")
									.equals("0")
									&& resultSetLogin
											.getString("lableadername") != null) {
								dataMap = new HashMap<String, String>();
								dataMap.put("url", url);
								dataMap.put("desig", "te");
								dataMap.put("error", "nil");
								dataList.add(dataMap);
								out.write(JSON.encode(dataList));
							} else if (resultSetLogin.getString("pmocheck")
									.equals("0")
									&& resultSetLogin
											.getString("lableadername") == null) {
								dataMap = new HashMap<String, String>();
								dataMap.put("url", url);
								dataMap.put("desig", "ll");
								dataMap.put("error", "nil");
								dataList.add(dataMap);
								out.write(JSON.encode(dataList));
							} else if (resultSetLogin.getString("pmocheck")
									.equals("1")
									&& resultSetLogin
											.getString("lableadername") == null) {
								dataMap = new HashMap<String, String>();
								dataMap.put("url", url);
								dataMap.put("desig", "pmo");
								dataMap.put("error", "nil");
								dataList.add(dataMap);
								out.write(JSON.encode(dataList));
							}
						} else {
							dataMap = new HashMap<String, String>();
							dataMap.put("error", "perror");
							dataList.add(dataMap);
							out.write(JSON.encode(dataList));
						}
					} else {
						dataMap = new HashMap<String, String>();
						dataMap.put("error", "rerror");
						dataList.add(dataMap);
						out.write(JSON.encode(dataList));
					}
				}
			} else {
				dataMap = new HashMap<String, String>();
				dataMap.put("error", "merror");
				dataList.add(dataMap);
				out.write(JSON.encode(dataList));
			}
		}

		catch (SQLException e) {

			e.printStackTrace();
		} finally {
			try {
				if (statement != null)
					statement.close();
			} catch (SQLException sqlException) {

			}
			try {
				if (connection.connect() != null)
					connection.connect().close();
			} catch (SQLException sqlException) {
				sqlException.printStackTrace();
			}
		}
	}
}