import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;

public class Leave_password_encrypt {

	public static String encryption(String password)
			throws NoSuchAlgorithmException, NoSuchProviderException {
		MessageDigest md = MessageDigest.getInstance("MD5");
		byte[] messageDigest = md.digest(password.getBytes());
		BigInteger bg = new BigInteger(1, messageDigest);
		String hashtext = bg.toString(16);
		return hashtext;
		// md5online.org
	}
}
