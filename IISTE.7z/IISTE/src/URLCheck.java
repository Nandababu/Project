import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.arnx.jsonic.JSON;

/**
 * URLCheck loads the data from URL
 */
public class URLCheck extends HttpServlet {
	private static final long serialVersionUID = 1L;
	connections connection = new connections();
	Statement statement = null;
	ResultSet resultSetURL;
	userCheck chkusr = new userCheck();
	String empname;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public URLCheck() {
		super();
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		PrintWriter out = response.getWriter();
		List<List<Map<String, String>>> resultList = new ArrayList<List<Map<String, String>>>();
		List<Map<String, String>> dataList = new ArrayList<Map<String, String>>();
		Map<String, String> dataMap = null;
		dataMap = new HashMap<String, String>();
		if ((session.getId()).equals(request.getParameter("session"))) {
			// session.invalidate();
			try {
				statement = connection.connect().createStatement();
				String id = request.getParameter("userid");
				String key = request.getParameter("authKey");
				String chk = chkusr.doCheckUser(id, key);
				if (chk.equals("1")) {
					String query = "select employeename from info_leave_master_data where employeeid='"
							+ id + "'";
					ResultSet rs = statement.executeQuery(query);
					while (rs.next()) {
						empname = rs.getString("employeename");
					}
					String dataRetrieve = "select * from info_leave_master_data i1,info_leave_data i2 where i1.employeeid like '"
							+ id + "' and i2.employeeid like '" + id + "'";
					resultSetURL = statement.executeQuery(dataRetrieve);
					while (resultSetURL.next()) {
						dataMap.put("id",
								(resultSetURL.getString("EMPLOYEEID")));
						dataMap.put("name",
								(resultSetURL.getString("EMPLOYEENAME")));
						dataMap.put("projectname",
								(resultSetURL.getString("PROJECTNAME")));
						dataMap.put("llname",
								(resultSetURL.getString("LABLEADERNAME")));
						dataMap.put("pmoname",
								(resultSetURL.getString("PMONAME")));
						dataMap.put("pmocheck",
								(resultSetURL.getString("PMOCHECK")));
						dataMap.put("casualcount",
								(resultSetURL.getString("CASUALLEAVECOUNT")));
						dataMap.put("sickcount",
								(resultSetURL.getString("SICKLEAVECOUNT")));
						dataMap.put("permission",
								(resultSetURL.getString("PERMISSIONHOURS")));
						dataList.add(dataMap);
						if (resultSetURL.getString("LABLEADERNAME") == null
								&& resultSetURL.getString("PMOCHECK").equals(
										"1")) {
							resultList.add(dataList);
							out.write(JSON.encode(resultList));
						} else if (resultSetURL.getString("LABLEADERNAME") == null
								&& resultSetURL.getString("PMOCHECK").equals(
										"0")) {
							resultList.add(dataList);
							out.write(JSON.encode(resultList));
						} else {
							resultList.add(dataList);
							out.write(JSON.encode(resultList));
						}

					}
				} else {
					session.invalidate();
					dataMap.put("error", "invalidate");
					dataList.add(dataMap);
					out.write(JSON.encode(dataList));
				}
			} catch (SQLException e) {

				e.printStackTrace();
			} finally {
				try {
					if (statement != null)
						statement.close();
				} catch (SQLException sqlException) {

				}
				try {
					if (connection.connect() != null)
						connection.connect().close();

				} catch (SQLException sqlException) {
					sqlException.printStackTrace();
				}
			}
		} else {
			dataMap.put("error", "invalidate");
			dataList.add(dataMap);
			out.write(JSON.encode(dataList));
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		PrintWriter out = response.getWriter();
		if ((session.getId()).equals(request.getParameter("session"))) {
			session.invalidate();
			out.write("invalidate");
		}
	}
}
