import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class connections {
	public Connection connect() throws SQLException {
		Connection connection = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException ex) {
			System.exit(1);
		}
		try {
			connection = DriverManager.getConnection(
					"jdbc:oracle:thin:@192.168.50.228:1521:cws", "tools",
					"tools");
		} catch (SQLException e) {
			System.exit(1);
		}
		return connection;
	}
}