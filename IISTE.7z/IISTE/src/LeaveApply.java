import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LeaveApply extends HttpServlet {
	private static final long serialVersionUID = 1L;
	connections connection = new connections();
	Statement statement = null;
	ResultSet resultSetURL;
	userCheck chkusr = new userCheck();
	String empName, pmoCheck, labLeader;

	public LeaveApply() {
		super();
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		try {
			statement = connection.connect().createStatement();
			PrintWriter out = response.getWriter();
			String id = request.getParameter("userid");
			String key = request.getParameter("authKey");
			String chk = chkusr.doCheckUser(id, key);
			String permissionQuery = null, leaveQuery = null, dateCount = null;
			int leaveStatus = 0, permissionStatus = 0;
			// Checks user name and password
			if (chk.equals("1")) {
				String getName = "select i1.employeename,i1.lableadername,i2.pmocheck from info_leave_master_data i1, info_leave_data i2 where i1.employeeid like '"
						+ id + "' and i2.employeeid like '" + id + "'";
				resultSetURL = statement.executeQuery(getName);
				while (resultSetURL.next()) {
					empName = resultSetURL.getString("employeename");
					labLeader = resultSetURL.getString("lableadername");
					pmoCheck = resultSetURL.getString("pmocheck");
				}
				if (pmoCheck.equals("0") && labLeader == null) {
					leaveStatus = 6;
					permissionStatus = 3;
				}
				// mode indicates to type of leave going to taken
				if (request.getParameter("mode").equals("leave")) {
					// leaveCountCheck used to check casual or sick leave count
					if (chkusr.leaveCountCheck(
							request.getParameter("leaveType"),
							Float.parseFloat(request.getParameter("NoDays")),
							id)) {
						String leaveType = request.getParameter("leaveType");
						float noDays = Float.parseFloat(request
								.getParameter("NoDays"));
						String leaveReason = request
								.getParameter("leaveReason");
						String leaveDate = request.getParameter("leaveDate");
						SimpleDateFormat source = new SimpleDateFormat(
								"MM/dd/yyyy");
						SimpleDateFormat target = new SimpleDateFormat(
								"yyyy-MM-dd");
						String newDate = target.format(source.parse(leaveDate));
						dateCount = chkusr.dateCheckValidate(id, newDate,
								noDays, 0);
						if (dateCount.equals("approveInsert")) {
							leaveQuery = "insert into INFO_LEAVE_UPDATE(employeeid, employeename, requesteddays, leavetype, requestedleavereason, requestedleavedate, leavestatus)"
									+ "values('"
									+ id
									+ "','"
									+ empName
									+ "',"
									+ noDays
									+ ",'"
									+ leaveType
									+ "','"
									+ leaveReason
									+ "',TO_DATE('"
									+ newDate
									+ "','YYYY-MM-DD')," + leaveStatus + ")";
							int execute = statement.executeUpdate(leaveQuery);
							if (execute > 0) {
								out.write("success");
							}
							connection.connect().commit();
						} else if (dateCount.equals("approveLeaveUpdate")) {
							leaveQuery = " update info_leave_update set requesteddays= "
									+ noDays
									+ ", leavetype='"
									+ leaveType
									+ "', requestedleavereason='"
									+ leaveReason
									+ "', requestedleavedate= TO_DATE('"
									+ newDate
									+ "', 'YYYY-MM-DD'),leavestatus= "
									+ leaveStatus
									+ "where employeeid='"
									+ id
									+ "' AND requestedpermissiondate=TO_DATE('"
									+ newDate + "', 'YYYY-MM-DD')";
							int execute = statement.executeUpdate(leaveQuery);
							if (execute > 0) {
								out.write("success");
							}
							connection.connect().commit();
						} else if (dateCount.equals("approveLeaveUpdateStatus")) {
							leaveQuery = " update info_leave_update set requesteddays= "
									+ noDays
									+ ", leavetype='"
									+ leaveType
									+ "', requestedleavereason='"
									+ leaveReason
									+ "', requestedleavedate= TO_DATE('"
									+ newDate
									+ "', 'YYYY-MM-DD'),leavestatus="
									+ leaveStatus
									+ "where employeeid='"
									+ id
									+ "' AND requestedleavedate=TO_DATE('"
									+ newDate + "', 'YYYY-MM-DD')";
							int execute = statement.executeUpdate(leaveQuery);
							if (execute > 0) {
								out.write("Reappliedsuccess");// re applied for
																// leave
							}
							connection.connect().commit();
						} else if (dateCount
								.equals("updateLeaveDeletePermission")) {
							leaveQuery = " update info_leave_update set requesteddays= "
									+ noDays
									+ ", leavetype='"
									+ leaveType
									+ "', requestedleavereason='"
									+ leaveReason
									+ "', requestedleavedate= TO_DATE('"
									+ newDate
									+ "', 'YYYY-MM-DD'),leavestatus="
									+ leaveStatus
									+ " , requestedpermissionhours='', requestedpermissionreason='', requestedpermissiondate='' ,permissionstatus='' "
									+ "where employeeid='"
									+ id
									+ "' AND requestedpermissiondate=TO_DATE('"
									+ newDate + "', 'YYYY-MM-DD')";
							int execute = statement.executeUpdate(leaveQuery);
							if (execute > 0) {
								out.write("lspr");// leave success permission
													// removed
							}
							connection.connect().commit();
						} else if (dateCount.equals("leaveAlreadyRegistered")) {
							out.write("leaveregistered");
						}
					} else {
						out.write(request.getParameter("leaveType"));
					}
				} else if (request.getParameter("mode").equals("permission")) {
					if (chkusr.leaveCountCheck("Permission",
							Float.parseFloat(request
									.getParameter("permissionHours")), id)) {
						float permissionHours = Float.parseFloat(request
								.getParameter("permissionHours"));
						String permissionReason = request
								.getParameter("permissionReason");
						String permissionDate = request
								.getParameter("permissionDate");
						SimpleDateFormat source = new SimpleDateFormat(
								"MM/dd/yyyy");
						SimpleDateFormat target = new SimpleDateFormat(
								"yyyy-MM-dd");
						String newDate = target.format(source
								.parse(permissionDate));
						dateCount = chkusr.dateCheckValidate(id, newDate, 0,
								permissionHours);
						if (dateCount.equals("approveInsert")) {
							permissionQuery = "insert into INFO_LEAVE_UPDATE (employeeid, employeename,requestedpermissionhours,requestedpermissionreason, requestedpermissiondate, permissionstatus) "
									+ "values ('"
									+ id
									+ "','"
									+ empName
									+ "', "
									+ permissionHours
									+ ",'"
									+ permissionReason
									+ "',TO_DATE('"
									+ newDate
									+ "','YYYY-MM-DD'),"
									+ permissionStatus + ")";

							int execute = statement
									.executeUpdate(permissionQuery);
							if (execute > 0) {
								out.write("success");
							}
							connection.connect().commit();
						} else if (dateCount.equals("permissionApproveUpdate")) {
							permissionQuery = " update info_leave_update set requestedpermissionhours= "
									+ permissionHours
									+ ", requestedpermissionreason='"
									+ permissionReason
									+ "', requestedpermissiondate= TO_DATE('"
									+ newDate
									+ "', 'YYYY-MM-DD'),permissionstatus="
									+ permissionStatus
									+ "where employeeid='"
									+ id
									+ "' AND requestedleavedate=TO_DATE('"
									+ newDate + "', 'YYYY-MM-DD')";
							int execute = statement
									.executeUpdate(permissionQuery);
							if (execute > 0) {
								out.write("success");
							}
							connection.connect().commit();
						} else if (dateCount
								.equals("permissionApproveUpdateStatus")) {
							permissionQuery = " update info_leave_update set requestedpermissionhours= "
									+ permissionHours
									+ ", requestedpermissionreason='"
									+ permissionReason
									+ "', requestedpermissiondate= TO_DATE('"
									+ newDate
									+ "', 'YYYY-MM-DD'),permissionstatus="
									+ permissionStatus
									+ "where employeeid='"
									+ id
									+ "' AND requestedpermissiondate=TO_DATE('"
									+ newDate + "', 'YYYY-MM-DD')";
							int execute = statement
									.executeUpdate(permissionQuery);
							if (execute > 0) {
								out.write("Reappliedsuccess");
							}
							connection.connect().commit();
						} else if (dateCount
								.equals("updatePermissionDeleteLeave")) {
							permissionQuery = " update info_leave_update set requestedpermissionhours= "
									+ permissionHours
									+ ", requestedpermissionreason='"
									+ permissionReason
									+ "', requestedpermissiondate= TO_DATE('"
									+ newDate
									+ "', 'YYYY-MM-DD'),permissionstatus="
									+ permissionStatus
									+ " , requesteddays='', leavetype='', requestedleavereason='',requestedleavedate='' ,leavestatus='' "
									+ "where employeeid='"
									+ id
									+ "' AND requestedleavedate=TO_DATE('"
									+ newDate + "', 'YYYY-MM-DD')";
							int execute = statement
									.executeUpdate(permissionQuery);
							if (execute > 0) {
								out.write("pslr");// permission success leave
													// removed
							}
							connection.connect().commit();
						} else if (dateCount
								.equals("permissionAlreadyRegistered")) {
							out.write("permissionregistered");
						}
					} else {
						out.write("permission");
					}
				}
			} else {
				out.write("invalidate");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		} finally {
			try {
				if (statement != null)
					statement.close();
			} catch (SQLException sqlException) {
				sqlException.printStackTrace();
			}
			try {
				if (connection.connect() != null)
					connection.connect().close();

			} catch (SQLException sqlException) {
				sqlException.printStackTrace();
			}
		}
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
	}

}
