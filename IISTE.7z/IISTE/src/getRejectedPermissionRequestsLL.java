import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.arnx.jsonic.JSON;

/**
 * Servlet implementation class getAcceptedLeaveRequestsLL
 */
public class getRejectedPermissionRequestsLL extends HttpServlet {
	private static final long serialVersionUID = 1L;
	connections connection = new connections();
	Statement statement = null;
	ResultSet resultSetURL;
	userCheck chkusr = new userCheck();
	String empname;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public getRejectedPermissionRequestsLL() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		List<List<Map<String, String>>> resultList = new ArrayList<List<Map<String, String>>>();
		List<Map<String, String>> leaveList = new ArrayList<Map<String, String>>();
		Map<String, String> leaveMap = null;
		PrintWriter out = response.getWriter();
		try {
			statement = connection.connect().createStatement();
			String id = request.getParameter("userid");
			String query = "select employeename from info_leave_master_data where employeeid='"
					+ id + "'";
			ResultSet rs = statement.executeQuery(query);
			while (rs.next()) {
				empname = rs.getString("employeename");
			}
			String leaveAcceptedDetails = "select e1.employeeid, e1.employeename,"
					+ " e2.requestedpermissionreason , e2.requestedpermissiondate from info_leave_master_data e1,"
					+ " info_leave_update e2 where e1.lableadername='"
					+ empname
					+ "' and"
					+ " e1.employeeid=e2.employeeid and e2.permissionstatus=2";
			ResultSet leaveResult = statement
					.executeQuery(leaveAcceptedDetails);
			while (leaveResult.next()) {
				leaveMap = new HashMap<String, String>();
				String leaveDate = leaveResult.getString(
						"requestedpermissiondate").substring(0, 10);
				leaveMap.put("id", leaveResult.getString("employeeid"));
				leaveMap.put("name", leaveResult.getString("employeename"));
				leaveMap.put("reason",
						leaveResult.getString("requestedpermissionreason"));
				leaveMap.put("date", leaveDate);
				leaveList.add(leaveMap);
			}
			resultList.add(leaveList);
			out.write(JSON.encode(resultList));
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			try {
				if (statement != null)
					statement.close();
			} catch (SQLException sqlException) {

			}
			try {
				if (connection.connect() != null)
					connection.connect().close();

			} catch (SQLException sqlException) {
				sqlException.printStackTrace();
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
